"""
Solving FrozenLake8x8 environment using Value-Itertion.
Author : Moustafa Alzantot (malzantot@ucla.edu)
"""
import time
import numpy as np
import gym
from gym import wrappers


def run_episode(env, policy, gamma = 1.0, render = False):
    """ Evaluates policy by using it to run an episode and finding its
    total reward.
    args:
    env: gym environment.
    policy: the policy to be used.
    gamma: discount factor.
    render: boolean to turn rendering on/off.
    returns:
    total reward: real value of the total reward recieved by agent under policy.
    """
    obs = env.reset()
    total_reward = 0
    step_idx = 0
    while True:
        if render:
            env.render()
        obs, reward, done , _ = env.step(int(policy[obs]))
        total_reward += (gamma ** step_idx * reward)
        step_idx += 1
        if done:
            break
    return total_reward


def evaluate_policy(env, policy, gamma = 1.0,  n = 100):
    """ Evaluates a policy by running it n times.
    returns:
    average total reward
    """
    scores = []
    for i in range(n):
        # print('Episode', i, 'being ran')
        scores.append(run_episode(env, policy, gamma = gamma, render = False))

    # scores = [
    #         run_episode(env, policy, gamma = gamma, render = False)
    #         for _ in range(n)]
    return np.mean(scores), np.std(scores)

def extract_policy(v, gamma = 1.0):
    """ Extract the policy given a value-function """
    policy = np.zeros(env.observation_space.n)
    for s in range(env.observation_space.n):
        q_sa = np.zeros(env.action_space.n)
        for a in range(env.action_space.n):
            # env.P = dictionary of states to actions with their corresponding [probability, next state, reward, if game is done]
            for next_sr in env.P[s][a]:
                # print('Starting at:', s)
                # print('Take action:', a)
                # print(next_sr)
                # next_sr is a tuple of (probability, next state, reward, done)
                p, s_, r, _ = next_sr
                q_sa[a] += (p * (r + gamma * v[s_]))
        policy[s] = np.argmax(q_sa)
    return policy


'''VALUE ITERATION'''

def value_iteration(env, gamma = 1.0):
    """ Value-iteration algorithm """
    v = np.zeros(env.observation_space.n)  # initialize value-function
    max_iterations = 100000
    eps = 1e-20
    t_start = time.time()
    for i in range(max_iterations):
        prev_v = np.copy(v)
        for s in range(env.observation_space.n):
            q_sa = [sum([p*(r + prev_v[s_]) for p, s_, r, _ in env.P[s][a]]) for a in range(env.action_space.n)]
            v[s] = max(q_sa)
        if (np.sum(np.fabs(prev_v - v)) <= eps):
            print ('Value-iteration converged at iteration# %d.' %(i+1))
            break
    t_end = time.time()
    print('Time lapsed:', t_end - t_start)
    return v


'''POLICY ITERATION'''

def compute_policy_v(env, policy, gamma=1.0):
    """ Iteratively evaluate the value-function under policy.
    Alternatively, we could formulate a set of linear equations in iterms of v[s]
    and solve them to find the value function.
    """
    v = np.zeros(env.observation_space.n)
    eps = 1e-20
    while True:
        prev_v = np.copy(v)
        for s in range(env.observation_space.n):
            policy_a = policy[s]
            v[s] = sum([p * (r + gamma * prev_v[s_]) for p, s_, r, _ in env.P[s][policy_a]])
        if (np.sum((np.fabs(prev_v - v))) <= eps):
            # value converged
            break
    return v


def policy_iteration(env, gamma = 1.0):
    """ Policy-Iteration algorithm """
    policy = np.random.choice(env.action_space.n, size=(env.observation_space.n))  # initialize a random policy
    max_iterations = 200000
    t_start = time.time()
    for i in range(max_iterations):
        old_policy_v = compute_policy_v(env, policy, gamma)
        new_policy = extract_policy(old_policy_v, gamma)
        if (np.all(policy == new_policy)):
            print ('Policy-Iteration converged at step %d.' %(i+1))
            break
        policy = new_policy
    t_end = time.time()
    print('Time lapsed:', t_end - t_start)
    return policy


if __name__ == '__main__':
    # Variables to change
    envs = ['FrozenLake-v0', 'FrozenLake8x8-v0']
    env_name  = envs[0]
    gamma = 0.99
    env = gym.make(env_name)
    env = env.unwrapped          # Required to access particular attributes
    # ACTIONS: [0,1,2,3] = [L, D, R, U]


    optimal_v = value_iteration(env, gamma);
    v_policy = extract_policy(optimal_v, gamma)
    v_policy_score, v_policy_std = evaluate_policy(env, v_policy, gamma, n=1000)
    print('Value-iteration policy:', v_policy)
    print('Value-iteration policy average score = ', v_policy_score, '+/-', v_policy_std)
    print('-------------------')

    p_policy = policy_iteration(env, gamma)
    p_policy_score, p_policy_std = evaluate_policy(env, p_policy, gamma, n=1000)
    print('Policy-iteration policy:', p_policy)
    print('Policy-iteration policy average score = ', p_policy_score, '+/-', p_policy_std)
    print('-------------------')
